<script>import stories from '$lib/stories.json';</script>
{#each stories as s}<a class="card" href={'/story/' + s.id}><b>{s.title}</b><div class="muted">{s.level}</div></a>{/each}
