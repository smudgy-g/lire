<script>
  import { onMount } from 'svelte';
  let items = [], topics = ['news', 'software'], loading = true, failed = 0;
  async function load() {
    loading = true;
    try { const j = await (await fetch('/api/feed?topics=' + topics.join(','))).json(); items = j.items; failed = j.failed; } catch { items = []; }
    loading = false;
  }
  onMount(() => { try { topics = JSON.parse(localStorage.getItem('topics')) || topics; } catch {} load(); });
  function toggle(t) { topics = topics.includes(t) ? topics.filter((x) => x != t) : [...topics, t]; localStorage.setItem('topics', JSON.stringify(topics)); load(); }
  const names = { news: 'Actualités', software: 'Logiciel' };
</script>
<div style="display:flex;gap:8px;margin-bottom:8px">{#each Object.keys(names) as t}<button style={topics.includes(t) ? 'background:var(--acc);color:var(--bg)' : ''} on:click={() => toggle(t)}>{names[t]}</button>{/each}</div>
{#if loading}<p class="muted">Chargement…</p>{/if}
{#each items as i}
  <a class="card" href={'/read?url=' + encodeURIComponent(i.link)}><b>{i.title}</b><div class="muted">{i.source} · {i.date ? new Date(i.date).toLocaleDateString('fr-FR') : ''}</div>{#if i.summary}<div style="font-size:15px">{i.summary}</div>{/if}</a>
{/each}
{#if !loading && !items.length}<p class="muted">No articles. Check the feed URLs in src/lib/feeds.js.</p>{/if}
{#if failed}<p class="muted">{failed} feed(s) failed to load.</p>{/if}
