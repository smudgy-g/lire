import { json } from '@sveltejs/kit';
import { lexGloss } from '$lib/server/nlp.js';
export async function GET({ url }) {
  const w = (url.searchParams.get('word') || '').trim();
  if (!w) return json({ g: null });
  const hdr = { 'cache-control': 'public, max-age=86400' };
  const l = lexGloss(w); if (l) return json({ g: l }, { headers: hdr });
  try {
    const r = await fetch('https://en.wiktionary.org/api/rest_v1/page/definition/' + encodeURIComponent(w.toLowerCase().replace(/’$/, '')),
      { headers: { 'user-agent': 'lire-en-francais/0.1 (personal learning app)' }, signal: AbortSignal.timeout(6000) });
    if (!r.ok) return json({ g: null });
    const j = await r.json(); const d = j?.fr?.[0]?.definitions?.[0]?.definition;
    return json({ g: d ? d.replace(/<[^>]+>/g, '').slice(0, 120) : null }, { headers: hdr });
  } catch { return json({ g: null }); }
}
