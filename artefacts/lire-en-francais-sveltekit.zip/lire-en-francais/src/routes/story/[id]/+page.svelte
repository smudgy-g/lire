<script>
  import { page } from '$app/stores';
  import stories from '$lib/stories.json';
  import Reader from '$lib/Reader.svelte';
  import { tokenizeStory } from '$lib/tokenize.js';
  import { speak } from '$lib/store.js';
  $: s = stories.find((x) => x.id === $page.params.id);
  $: paras = s ? tokenizeStory(s.text) : [];
  $: opts = s ? s.quiz.options.map((t, i) => ({ t, i })).sort(() => Math.random() - 0.5) : [];
  let fb = '';
  $: s, (fb = '');
</script>
{#if s}
  <h2>{s.title} <small class="muted">{s.level}</small></h2>
  <button on:click={() => speak(s.text.replace(/\[([^=\]]+)=[^\]]+\]/g, '$1'))}>▶ Écouter</button>
  <Reader paragraphs={paras} />
  <div class="card"><b>{s.quiz.question}</b>
    {#each opts as o}<button class="card" style="width:100%;text-align:left" on:click={() => (fb = o.i == 0 ? 'Correct !' : 'Pas tout à fait. Relisez le texte.')}>{o.t}</button>{/each}
    <div class="muted">{fb}</div></div>
{:else}<p>Story not found.</p>{/if}
