<script>
  import { cards, speak } from '$lib/store.js';
  let flip = false;
  $: due = $cards.filter((c) => !c.d || c.d <= Date.now());
  $: c = due[0];
  function grade(ok) {
    const D = [0, 1, 3, 7, 14, 30], i = $cards.indexOf(c);
    cards.update((a) => { const x = { ...a[i] }; x.b = ok ? Math.min((x.b || 0) + 1, 5) : 0; x.d = Date.now() + D[x.b] * 864e5 + (ok ? 0 : 6e4); a[i] = x; return [...a]; });
    flip = false;
  }
  function exp() { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify({ cards: $cards }, null, 1)], { type: 'application/json' })); a.download = 'lire-progress.json'; a.click(); }
  async function imp(e) { try { const d = JSON.parse(await e.target.files[0].text()); cards.set(d.cards || []); } catch { alert('Invalid file'); } }
</script>
{#if !$cards.length}<div class="card muted">No cards yet. Tap a word, then Save.</div>
{:else if !c}<div class="card muted">All caught up. {$cards.length} cards scheduled for later.</div>
{:else}
  <!-- svelte-ignore a11y_click_events_have_key_events, a11y_no_static_element_interactions -->
  <div class="card" style="min-height:140px;display:flex;align-items:center;justify-content:center;text-align:center;font-size:26px;cursor:pointer" on:click={() => { flip = !flip; if (flip) speak(c.f); }}>{flip ? c.t : c.f}</div>
  <div class="muted" style="text-align:center">{due.length} due · tap to flip</div>
  <div style="display:flex;gap:8px;justify-content:center;margin:8px 0"><button on:click={() => grade(false)}>Encore</button><button on:click={() => grade(true)}>Je sais ✓</button></div>
{/if}
<div style="display:flex;gap:8px;justify-content:center;margin-top:16px"><button on:click={exp}>Export</button><label><button on:click={(e) => e.currentTarget.nextElementSibling.click()}>Import</button><input type="file" accept=".json" hidden on:change={imp} /></label></div>
