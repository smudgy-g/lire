<script>
  import { onMount } from 'svelte';
  import { page } from '$app/stores';
  import Reader from '$lib/Reader.svelte';
  let input = '', doc = null, err = '', busy = false;
  async function go() {
    const v = input.trim(); if (!v) return;
    busy = true; err = ''; doc = null;
    try {
      const r = await fetch('/api/article', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(/^https?:\/\/\S+$/.test(v) ? { url: v } : { text: v }) });
      if (!r.ok) err = (await r.json().catch(() => ({}))).message || 'Something went wrong'; else doc = await r.json();
    } catch { err = 'Network error'; }
    busy = false;
  }
  onMount(() => { const u = $page.url.searchParams.get('url'); if (u) { input = u; go(); } });
</script>
<textarea rows="3" placeholder="Paste an article URL or French text" bind:value={input}></textarea>
<div style="margin:8px 0"><button on:click={go} disabled={busy}>{busy ? 'Chargement…' : 'Lire'}</button></div>
{#if err}<p class="muted">{err}</p>{/if}
{#if doc}<h2>{doc.title}</h2>{#if doc.source}<div class="muted">{doc.source}</div>{/if}<Reader paragraphs={doc.paragraphs} />
<p class="muted">Orange underline: word is above your chosen level. Tap any word for its meaning.</p>{/if}
