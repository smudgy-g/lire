<script>
  import { onMount } from 'svelte';
  import { page } from '$app/stores';
  import { init, cards, level } from '$lib/store.js';
  onMount(init);
  const nav = [['/', 'Feed'], ['/read', 'Lire'], ['/stories', 'Histoires'], ['/cards', 'Cartes']];
</script>
<main>
  <nav>{#each nav as [h, l]}<a href={h} class:on={$page.url.pathname === h}>{l}{l === 'Cartes' ? ` (${$cards.length})` : ''}</a>{/each}
    <select bind:value={$level} title="Highlight words above this level"><option value={1}>A2</option><option value={2}>B1</option><option value={3}>B2</option></select></nav>
  <slot />
</main>
<style>
  :global(:root){--bg:#faf7f2;--card:#fff;--ink:#222;--mute:#6b6b6b;--acc:#1f4e9c;--accbg:#e6eefb;--line:#e4ded3;--hl:#fff3c4;--hard:#e8a33d}
  @media (prefers-color-scheme:dark){:global(:root){--bg:#16181d;--card:#1f2229;--ink:#ece9e2;--mute:#9a9a9a;--acc:#8db4ff;--accbg:#27324a;--line:#333843;--hl:#4a4320;--hard:#d9962f}}
  :global(body){margin:0;background:var(--bg);color:var(--ink);font:17px/1.7 Georgia,serif;padding:env(safe-area-inset-top) 0 env(safe-area-inset-bottom)}
  :global(*){box-sizing:border-box}
  main{max-width:680px;margin:0 auto;padding:12px 16px 80px}
  nav{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:12px;font:15px system-ui,sans-serif}
  nav a{padding:7px 14px;border:1px solid var(--line);border-radius:999px;color:var(--ink);text-decoration:none;background:var(--card)}
  nav a.on{background:var(--acc);color:var(--bg);border-color:var(--acc)}
  nav select{margin-left:auto}
  :global(.card){background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 18px;margin:10px 0;display:block;color:inherit;text-decoration:none}
  :global(button){font:15px system-ui,sans-serif;border:1px solid var(--line);background:var(--card);color:var(--ink);padding:8px 14px;border-radius:999px;cursor:pointer}
  :global(.muted){color:var(--mute);font:14px system-ui,sans-serif}
  :global(.u){cursor:pointer}:global(.u:hover){background:var(--accbg)}
  :global(.u.k){border-bottom:1.5px dotted var(--acc)}
  :global(.u.hard){border-bottom:2px solid var(--hard)}
  :global(.u.saved){background:var(--hl)}
  :global(.tip){position:fixed;left:12px;right:12px;bottom:calc(10px + env(safe-area-inset-bottom));max-width:656px;margin:0 auto;background:var(--card);border:1px solid var(--acc);border-radius:12px;padding:10px 14px;font:16px system-ui,sans-serif;display:flex;gap:10px;justify-content:space-between;align-items:center}
  :global(input,textarea){width:100%;font:16px system-ui,sans-serif;padding:10px;border:1px solid var(--line);border-radius:10px;background:var(--card);color:var(--ink)}
</style>
