<script>
  import { cards, level, speak } from '$lib/store.js';
  export let paragraphs = [];
  let sel = null, gloss = null;
  $: saved = new Set($cards.map((c) => c.f));
  async function tap(t) {
    sel = t; gloss = t.g || null; speak(t.s);
    if (!gloss) { try { const j = await (await fetch('/api/define?word=' + encodeURIComponent(t.s))).json(); if (sel === t) gloss = j.g || '(no definition found)'; } catch { gloss = '(offline)'; } }
  }
  const save = () => { if (sel && gloss && !gloss.startsWith('(')) cards.update((c) => (c.some((x) => x.f == sel.s) ? c : [...c, { f: sel.s, t: gloss }])); };
  const lab = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
</script>
<div class="card read">
  {#each paragraphs as p}
    <p>{#each p as t}{#if t.w}<!-- svelte-ignore a11y_click_events_have_key_events, a11y_no_static_element_interactions --><span class="u" class:k={t.k} class:hard={t.lv != null && t.lv > $level} class:saved={saved.has(t.s)} on:click={() => tap(t)}>{t.s}</span>{:else}{t.s}{/if}{/each}</p>
  {/each}
</div>
{#if sel}
  <div class="tip">
    <span><b>{sel.s}</b>{#if sel.lv != null} <small>{lab[sel.lv]}</small>{/if} · {gloss ?? '…'}</span>
    <button on:click={save}>{saved.has(sel.s) ? 'Saved ✓' : '+ Save'}</button>
  </div>
{/if}
