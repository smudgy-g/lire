# Lire en français

Read French stories and real articles with tap-to-translate words, level highlighting, audio and spaced-repetition flashcards.

## Pages
- `/` Feed: latest articles for your topics (news, software). Tap one to open it in the reader.
- `/read` Paste an article URL or French text.
- `/stories` Hand-written A2 to B2 stories with glosses and a question.
- `/cards` Saved words, reviewed on a schedule. Export / Import for backup.

## How it works
- `/api/article` fetches a URL, extracts the article text (Readability), splits it into words, and looks up each word's CEFR level.
- Levels come from FLELex (`data/FleLex_CRF.csv`). Words are matched by French stem (Snowball), so inflected forms like "déployons" and "déployer" share an entry. Stemming is approximate: a few unrelated words can share a stem.
- `/api/define` returns a meaning from `src/lib/server/lexicon.json`, then Wiktionary, and caches it.
- Orange underline = word above the level chosen in the selector. Dotted blue underline = key vocabulary in stories.
- Progress (saved words) lives in the browser (IndexedDB), not on the server.

## Run
    npm install
    npm run data      # rebuilds src/lib/server/levels.json from data/FleLex_CRF.csv
    npm run dev

## Deploy to Vercel
Push to GitHub, import the repo in Vercel, deploy with defaults (adapter-vercel is configured in `vite.config.js`).

## Before you push publicly
- Check the FLELex licence on the CEFRLex site. `data/FleLex_CRF.csv` and `levels.json` are derived from it. Keep the repo private until you have.
- Verify the feed URLs in `src/lib/feeds.js`; they were not tested from here.
- Some sites block server fetches or sit behind paywalls; use paste-text for those.
- `/api/article` only blocks obvious private addresses. It does not stop every kind of server-side request forgery, so add stricter checks before sharing the app widely.

## Not built yet
Share target for Android, accounts and sync, more topics, level estimates in the feed list.
