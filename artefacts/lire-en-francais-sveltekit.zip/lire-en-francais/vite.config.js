import adapter from '@sveltejs/adapter-vercel';
import { sveltekit } from '@sveltejs/kit/vite';
export default { plugins: [sveltekit({ adapter: adapter(), alias: { '$lib': 'src/lib' } })] };
