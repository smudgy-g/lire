// Builds src/lib/server/levels.json (stem -> CEFR level 0..5) from data/FleLex_CRF.csv
import fs from 'fs'; import snowball from 'snowball-stemmers';
const st = snowball.newStemmer('french'), out = {};
const rows = fs.readFileSync('data/FleLex_CRF.csv', 'utf8').split(/\r?\n/).slice(1);
for (const r of rows) {
  const c = r.split('\t'); const w = (c[0] || '').trim().toLowerCase();
  if (!w || w.includes(' ')) continue;
  const f = c.slice(2, 8).map(Number); const max = Math.max(...f);
  if (!(max > 0)) continue;
  const lv = f.findIndex(x => x >= 0.2 * max); const k = st.stem(w);
  out[k] = k in out ? Math.min(out[k], lv) : lv;
}
fs.writeFileSync('src/lib/server/levels.json', JSON.stringify(out));
console.log(Object.keys(out).length, 'stems');
