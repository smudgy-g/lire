# Lire en français (A2 to B2)

A small reading app for learning French. Tap underlined words for their meaning, listen to the story, answer a question, and review saved words as spaced-repetition flashcards. No build step, no dependencies.

## Files
- `index.html`: the app (HTML, CSS and JS in one file, plus a fallback copy of the stories).
- `stories.json`: the content. This is the "database" of stories.
- `lexicon.json`: a shared glossary of about 240 very common words, used when you tap a word that has no gloss in the story itself. Add entries as `"word": "meaning"`.
- Progress (saved words, completed stories) is stored in the visitor's browser (IndexedDB). Use Export / Import on the Cartes tab to back it up or move it to another device.

## Host on GitHub Pages (free)
1. Create a new public repository on GitHub.
2. Upload `index.html`, `stories.json` and `README.md` to the root of the repository.
3. Go to Settings, then Pages. Under "Build and deployment", choose "Deploy from a branch", pick `main` and `/ (root)`, then Save.
4. After a minute the site is live at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

## Run locally
`index.html` loads `stories.json` over http. If that fails (for example when you open the file directly), it falls back to a copy of the stories embedded in `index.html`, so edits to `stories.json` only show up when the site is served over http. To test locally, run inside the folder:

    python3 -m http.server

then open http://localhost:8000

## Add a story
Add an object to `stories.json`:

    {
      "id": "b1c",
      "level": "B1",
      "title": "My title",
      "text": "Paragraph one with a [mot=word] to translate.\n\nParagraph two.",
      "quiz": {
        "question": "A question in French ?",
        "options": ["Correct answer first", "Wrong answer", "Wrong answer"]
      }
    }

- Every word is tappable. Mark key vocabulary or phrases as `[french=english]` to give them a gloss and a highlighted underline. Other words use `lexicon.json`, then (online only) a Wiktionary lookup, then a link. Use `’` for apostrophes inside the text.
- The first option is always the correct one; the app shuffles them.
- `level` should be A2, B1 or B2 to show up under the level filters.
- Paragraphs are separated by `\n\n`.

## Notes
- Speech uses the browser's built-in French voice, so quality varies by device.
- Story levels are estimates. A check against the FLELex word list found no words far above level, but it could not tell the levels apart precisely.
